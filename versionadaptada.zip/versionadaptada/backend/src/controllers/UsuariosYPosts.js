export const getUsuarios = (req,res)=> {
    res.send("hello world")
}