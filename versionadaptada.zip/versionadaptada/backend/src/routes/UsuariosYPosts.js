import { Router } from "express";
import { getUsuarios } from "../controllers/UsuariosYPosts";
const router = Router()
router.get("/Usuarios", getUsuarios)
router.get("/Usuarios/count")
router.get("/Usuarios/:id")
router.post("/Usuarios")
router.delete("/Usuarios/:id")
router.put("/Usuarios/:id")
export default router