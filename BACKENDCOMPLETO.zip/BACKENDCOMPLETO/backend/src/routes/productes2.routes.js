import {Router} from 'express'
import { getRutinas } from '../controllers/products2.controllers'
const app = Router()
const getRutinas = getRutinas()
app.get('/Rutinas', getRutinas)

export default app