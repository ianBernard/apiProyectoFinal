import {Router} from 'express'
import { getUsuarios } from '../controllers/products.controllers'
const app = Router()
const getUsuarios = getUsuarios()
app.get('/Usuarios', getUsuarios)

export default app