import { getConnection } from "../database/connection";
export const getUsuarios = (req, res)=> {
    const pool = await getConnection()
    const result = await pool.request().query('SELECT * FROM Usuarios');
    console.log(result);
    res.json(result.recordset)    
}
