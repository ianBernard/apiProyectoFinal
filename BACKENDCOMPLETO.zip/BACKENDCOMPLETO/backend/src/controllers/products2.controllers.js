import { getConnection } from "../database/connection";
export const getRutinas = (req, res)=> {
    const pool = await getConnection();
    const result = await pool.request().query('SELECT * FROM Rutinas');
    console.log(result);
    res.json(result.recordset)    
}
