import express from 'express'
import config from './config'
import productRoutes from './routes/productRoutes'


const app = express()

//settings
app.set('port', config.port || 3000)
app.use(productRoutes)

export default app