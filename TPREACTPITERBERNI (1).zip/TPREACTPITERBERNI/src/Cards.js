
function Cards() {
  return (
    <div class="container">
    <div class="row">
        <div class="col-1"></div>
        <div class="col-10">
            <h4>Productos destacados</h4>
            <div class="card-deck">
                <div class="card border border-secondary">
                  <img src="img/Capa-1.png" class="card-img-top" alt="..." />
                  <div class="card-body text-center">
                    <h6 class="card-title">Lavatorio</h6>
                    <p class="card-text">Mueble colgante para lavatorio</p>
                  </div>
                </div>
                <div class="card border border-secondary">
                  <img src="img/Capa-1.png" class="card-img-top" alt="..."/>
                  <div class="card-body text-center">
                    <h6 class="card-title">Lavatorio</h6>
                    <p class="card-text">Mueble colgante para lavatorio</p>
                  </div>
                </div>
                <div class="card border border-secondary">
                  <img src="img/Capa-1.png" class="card-img-top" alt="..."/>
                  <div class="card-body text-center">
                    <h6>Lavatorio</h6>
                    <p class="card-text">Mueble colgante para lavatorio</p>
                  </div>
                </div>
              </div>
              <div class="card-margin"></div>
              <div class="card-deck">
                <div class="card border border-secondary">
                  <img src="img/Capa-1.png" class="card-img-top" alt="..."/>
                  <div class="card-body text-center">
                    <h6 class="card-title">Lavatorio</h6>
                    <p>Mueble colgante para lavatorio</p>
                  </div>
                </div>
                <div class="card border border-secondary">
                  <img src="img/Capa-1.png" class="card-img-top" alt="..."/>
                  <div class="card-body text-center">
                    <h6 class="card-title">Lavatorio</h6>
                    <p class="card-text">Mueble colgante para lavatorio</p>
                  </div>
                </div>
                <div class="card border border-secondary">
                  <img src="img/Capa-1.png" class="card-img-top" alt="..." />
                  <div class="card-body text-center">
                    <h6>Lavatorio</h6>
                    <p class="card-text">Mueble colgante para lavatorio</p>
                  </div>
                </div>
              </div>
        </div>
    </div>
</div>
       

       
  );
}
export default Cards;