import './bootstrap.min.css';
import './App.css';
import './styles.css';

import Navbar from './Navbar';
import Carousel from'./Carousel';
import Cards from'./Cards';
import Marcas from'./Marcas';
import Footer from'./Footer';
function App() {
  return (
    <div className="App">
      <Navbar />
      <Carousel/>
      <Cards/>
      <Marcas/>
      <Footer/>
   
      
    </div>
  );
}

export default App;
