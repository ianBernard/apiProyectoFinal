
import './Navbar.css';
function Navbar() {
    return (
        <div class="container-fluid">
        <div class="row">
            <div class="col-1"></div>
            <div class="col-10">
                <nav class="navbar navbar-expand-md navbar-light">
                    <a class="navbar-brand" href="#">
                        <img src="img/Logo.png" width="75" height="75" alt=""/>
                      </a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="true" aria-label="Toggle navigation">
                      <span class="navbar-toggler-icon"></span>
                    </button>
                  
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                      <ul class="navbar-nav ml-auto">
                        <li class="nav-item">
                          <a class="nav-link" href="#">INICIO</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">QUIENES SOMOS</a>
                          </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">PRODUCTOS</a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" href="#">CONTACTO</a>
                          </li>
                        </ul>
                    </div>
                  </nav>
                  </div>
            </div>
        </div>
    );
  }
  
  export default Navbar;