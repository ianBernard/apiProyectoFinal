function Footer(){
    return (
<footer class="bg-dark text-white">
<div class="row">
    <div class="col-1"></div>
    <div class="col-sm-4" id="footer1">
        <img src="img/logo_byn.png"/>
    </div>
    <div class="col-sm-4" id="footer2">
      <li>
        <p><img src="img/mapas-y-banderas.png " id="footer3"/>Beiro 3300 - Villa del parque</p>
      </li>
      <li>
        <p><img src="img/email.png" id="footer4"/>contacto@sanitarioscampana.com.ar</p>
      </li>
  </div>
  <div class="col-sm-3" id="footer5">
      <a href="#"><img src="img/tel.png"/> 4503-6015 </a> 
  </div>
</div>
</footer>
    );
}

export default Footer;
