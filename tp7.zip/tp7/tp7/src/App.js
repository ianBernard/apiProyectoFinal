import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
      <h1>ADMINISTRADOR DE PACIENTES</h1>
      <div id="root"></div>
        <div class="container">
          <div class="row">
            <div class="one-half column">
            <div class="one-half column">
      <h2>Crear mi Cita</h2>
      <form>
      <label>Nombre Mascota</label><input type="text" name="mascota" class="u-full-width" placeholder="Nombre Mascota" value=""></input>
      <label>Nombre Dueño</label><input type="text" name="propietario" class="u-full-width" placeholder="Nombre dueño de la mascota" value=""></input>
      <label>Fecha</label><input type="date" name="fecha" class="u-full-width" value=""></input>
      <label>hora</label><input type="time" name="hora" class="u-full-width" value=""></input>
      <label>Sintomas</label><input type="time" name="hora" class="u-full-width" value=""></input>
      <button type="submit" class="u-full-width button-primary">Agregar Cita</button>
      </form>
      </div>
              </div></div></div>
      
      </header>
    </div>
  );
}

export default App;
