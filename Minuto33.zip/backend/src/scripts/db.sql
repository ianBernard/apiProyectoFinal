CREATE DATABASE IF NOT EXISTS ProyectoFinal
USE ProyectoFinal
CREATE TABLE IF NOT EXISTS USUARIOS(
    idUsuario INT NOT NULL AUTO_INCREMENT,
    nombreUsuario VARCHAR(25) NOT NULL,
    contrasena VARCHAR(25) NOT NULL,
    nombre VARCHAR(15) NOT NULL,
    apellido VARCHAR(20) NOT NULL,
    mail TEXT NOT NULL
    PRIMARY KEY (id)
)
INSERT INTO USUARIOS(nombreUsuario,contrasena,nombre,apellido,mail) VALUES 
('BIGFELLA','IanBernardElMasFachero123', 'Ian', 'bernard', 'bernard.ian3@gmail.com')
