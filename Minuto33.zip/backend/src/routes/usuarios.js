import { Router } from "express";
import {actualizarUsuario, borrarUsuario, crearUsuario, verCantUsuario, verUsuario, verUsuarios} from "../controllers/usuarios"
const usuario =  Router();
usuario.get('/usuario', verUsuarios)
usuario.get('/usuario/count', verUsuario)
usuario.get('/usuario/:id', verCantUsuario)
usuario.put('/usuario', crearUsuario)
usuario.delete('/usuario/:id', borrarUsuario)
usuario.get('/usuario/:id', actualizarUsuario)
export default usuario