import express from "express"
import verUsuario from "./routes/usuarios"

const app=express()
app.use(verUsuario)

export default app