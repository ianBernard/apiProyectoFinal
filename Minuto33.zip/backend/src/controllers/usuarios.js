export const verUsuarios =(req, res)=>{
    res.send("hello");
}
export const verUsuario =(req, res)=>{
    res.send("hello");
}
export const verCantUsuario =(req, res)=>{
    res.send("hello");
}
export const crearUsuario =(req, res)=>{
    res.send("hello");
}
export const borrarUsuario =(req, res)=>{
    res.send("hello");
}
export const actualizarUsuario =(req, res)=>{
    res.send("hello");
}